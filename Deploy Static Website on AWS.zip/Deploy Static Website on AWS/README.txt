1. Websites Files
 
  Each step, please refer to image below

    - The S3 bucket is created.
        S3_bucket_created.png

    - A screenshot showing all the website les uploaded to the newly created S3 bucket.
        file_folder_uploaded.pnp

    - The S3 bucket is configured to support static website hosting.
        configured_web_static.png

    - The S3 bucket has an IAM bucket policy that makes the bucket contents publicly accessible.
        IAM_policy.png
    
2. Website Distribution

    CloudFront has been configured to retrieve and distribute website file
        CloudFront_distribution.png

3. Web Browser Access

    CloudFront domain name:
        https://daebnf4xl4exo.cloudfront.net/
    
    Access the website via website-endpoint:
        http://my-339713138146-bucket.s3-website.us-east-2.amazonaws.com
    
    Access the bucket object via its S3 object URL:
        https://my-339713138146-bucket.s3.amazonaws.com/index.html